# Respect 示例工作流

ComfyUI 里「工作流 → 打开」选这些 `.json` 即可载入（LiteGraph 图格式）。载入后把 `Respect API 设置` 节点里的 **api_key / base_url** 换成你自己的。

## 1. `1_image2_4k_text2img.json` —— image2 文生 4K 图

```
Respect API 设置 ──api_config──▶ Respect image2 文生图/图生图 ──image──▶ 预览图像
```
- base_url 默认 `https://api.aicopy.top`
- image2 节点：`model=gpt-image-2`、`resolution=4k`（长边 4096，如 16:9 → 4096×2304）
- 想图生图：给 image2 的 `image_1` 接一个「加载图像」，会自动走 `/v1/images/edits`

## 2. `2_llm_jsonschema_split_to_image.json` —— LLM 结构化分段 → 驱动生图

```
Respect API 设置 ─┬─api_config─▶ Respect Chat 对话 ──text──▶ Respect 分段提取 ─seg_1─▶ image2.prompt ─▶ 预览图像
                 └─api_config──────────────────────────────────────────────▶ image2.api_config
```
- Chat 节点：`response_format=json_schema`，`json_schema` 已填：
  ```json
  {"type":"object","properties":{"segments":{"type":"array","items":{"type":"string"}}},"required":["segments"],"additionalProperties":false}
  ```
  让 GPT 稳定返回 `{"segments":[...]}`
- 分段提取：`method=json`、`json_path=segments` → 切出 `seg_1..seg_8`
- 这里把 `seg_1` 接到 image2 的 `prompt`（第 1 段画面提示词直接生图）；换 `seg_2/seg_3` 即用其它段
- base_url 需用**同时有 chat 和 image 模型**的网关（示例填 `https://llm.xxttt.com`，按你实际网关改）

## 3. `3_pdf_to_video_pipeline.json` —— PDF → GPT分段 → 多图/多视频 → 拼接 → BGM → 保存（完整流水线）

一条龙示例（2 个场景为例，可自行加节点扩展更多场景）：

```
PDF批量转文字 ─text─┐
文字输入(提示词) ─┴─ 文字合并 ─▶ Chat(json_schema) ─▶ 分段提取(json, segments)
                                                          ├ seg_1 + 文字输入 → 合并 → image2_A → 图A ─┐
                                                          │                                          ├→ Grok视频A(首帧=图A) → 删首帧(2-) ─┐
                                                          ├ seg_2 + 文字输入 → 合并 ──────────prompt──┘                                   │
                                                          ├ seg_3 + 文字输入 → 合并 → image2_B → 图B ─┐                                   ├→ 视频拼接 → 加BGM ─┬→ 查看视频
                                                          │                                          ├→ Grok视频B(首帧=图B) → 删首帧(2-) ─┘                   └→ 保存视频(名=PDF stem)
                                                          └ seg_4 + 文字输入 → 合并 ──────────prompt──┘
PDF.stem ───────────────────────────────────────────────────────────────────────────────────────────────────▶ 保存视频.filename
```

要点：
- **PDF**：`folder_path` 已填测试文件 `巴西抛.pdf`，换成你的文件夹即可（`mode=increment` 逐个取）。
- **提示词 + PDF**：`文字输入(提示词)` 与 PDF 正文经 `文字合并` 一起进 Chat。
- **Chat**：`response_format=json_schema`，schema 为 `{"segments":[...]}`；提示词里要求「按顺序输出 4 段：场景1画面/场景1运镜/场景2画面/场景2运镜」。
- **分段**：`method=json`、`json_path=segments` → `seg_1..seg_4`。
- **每个场景**：画面段 + 一个 `文字输入`（风格）→ image2 出图；运镜段 + 一个 `文字输入` → Grok，**首帧 = image2 出的图**。
- **删首帧**：Grok 视频首帧就是那张图，用 `视频文件裁剪` `select=2-` 去掉第 1 帧。
- **拼接 → 加BGM**：两段去首帧后 `视频拼接`，再 `视频加BGM`（把 `audio_path` 换成你的音乐）。
- **预览 + 保存**：`查看视频` 播放；`保存视频` 的 `filename` 由 **PDF 的 stem**（无扩展名文件名）连过来，输出如 `巴西抛.mp4`。

> 想要更多场景：复制「文字输入×2 + 合并×2 + image2 + Grok + 删首帧」一组，把 `seg_5/seg_6…` 接上，再把删首帧的输出接到 `视频拼接` 的 `video_3/4…`。

## 4. `4_one_image_multi_video.json` —— 单张图 → 多个视频

和 #3 类似，但**只生成一张图**，这张图作为**多个 Grok 视频的首帧**，产出多个视频：

```
PDF批量转文字 ┐
文字输入(提示词) ┴→ 文字合并 → Chat(json_schema) → 分段提取(json, segments)
   ├ seg_1 + 文字输入(风格) → 合并 → image2 → 一张图 ─┬─首帧─▶ Grok视频A(seg_2+运镜文字) → 删首帧(2-) ┐
   │                                                  └─首帧─▶ Grok视频B(seg_3+运镜文字) → 删首帧(2-) ┤
   ├ seg_2 + 文字输入 → 合并 ─────prompt──────────────────────────▶ Grok视频A                        ├→ 视频拼接 → 加BGM ┬→ 查看视频
   └ seg_3 + 文字输入 → 合并 ─────prompt──────────────────────────▶ Grok视频B                        │                  └→ 保存视频(名=PDF stem)
PDF.stem ────────────────────────────────────────────────────────────────────────────────────────▶ 保存视频.filename
```

差别只在：**image2 只有一个**，它的 `image` 输出**同时连到 GrokA 和 GrokB 的 `first_frame`**（一张图喂多个视频）。让 GPT 输出 3 段：画面提示词 + 视频A运镜 + 视频B运镜。想更多视频就再复制「文字输入+合并+Grok+删首帧」一组，`first_frame` 都连同一个 image2 的输出，`prompt` 接 seg_4/seg_5…，删首帧后接 `视频拼接` 的 video_3/4…。

## 分镜三段式（文件系统任务队列，可断点续跑、防重复）

把复杂流程拆成三个工作流，用一个 root 路径（默认 `output/respect_storyboard`）传递任务。目录结构：

```
<root>/01_pending/<scene>/image.png + prompts/00X.txt   # 待做
       02_done_prompts/<scene>/00X.txt                  # 提示词做完移这
       03_videos/<scene>/00X.mp4                          # 删帧后视频，按 scene 成批
       04_done_scenes/<scene>/image.png                   # 该 scene 全做完，图移这
```

### A. `A_storyboard_save.json` —— 分镜存储（生产者）
```
PDF + 文字输入(提示词) → 合并 → Chat(json_schema: {image, videos[]})
  ├ 分段提取(json_path=image)  → seg_1 → image2 → 图
  └ 分段提取(json_path=videos) → all_json ─┐
                                    图 + all_json → Respect 分镜存储 → 写入 01_pending/<scene>/
```
Chat 按 schema 返回「一个画面提示词 image + 多个视频提示词 videos[]」；一张图绑定多个视频提示词（一对多）落盘。跑一次存一个 scene。

### B. `B_video_produce.json` —— 视频制作（消费者，每次跑 1 个任务）
```
Respect 分镜取任务(root) → image + prompt + scene_id + seq
  ├ prompt → Respect 提取镜头秒数(offset=1 补删帧) → seconds ─┐
  └ image + prompt ──────────────────────────────────────────┤
  → Grok-Video(坤鸡分支, 图生视频, first_frame=image, prompt=prompt, duration=seconds)
  → 视频文件裁剪(select=2- 删首帧) → Respect 分镜完成归档(scene_id, seq, video_path)
```
每次运行处理**一个** (图,提示词)：从提示词里抠出镜头秒数、+1 秒补删帧 → 作为 grok 的 `duration`；出视频→删首帧→归档到 `03_videos/<scene>`，提示词移到 `02_done_prompts`；该 scene 提示词全做完，图片才移到 `04_done_scenes`。**开 Auto Queue 就能把整个队列跑完**（`has_job=false` 表示空了）。做完即移走，不会重复。

> 让 A 的 LLM 在每条视频提示词里带上秒数（如 `8秒 | 人物走动…`），B 的「提取镜头秒数」就能抠到；抠不到用 default。`duration` 需在 grok 节点上右键把它转为输入再连。

### C. `C_merge_bgm_save.json` —— 合并 + BGM + 保存
```
Respect 视频拼接(folder=<root>/03_videos/<scene>, bgm_audio, bgm_stage) → 查看视频 + 保存视频
```
- `folder` 填某个 scene 的 `03_videos` 目录 → 自动按名排序**整批拼接**
- `bgm_stage`：`none` 不加 / `after_merge` 合并后统一加 / `per_video` 每个视频各加再合并（这就是「单视频 or 合并后」的**开关**）
- 拼好 → 预览 + 保存

> 用前改：三个工作流的 `root_dir` 保持一致；A 的 base_url 用有 chat+image 的网关，B 的用坤鸡（grok）；C 的 `folder`/`bgm_audio` 按实际填。

### 循环运行 B（把整个队列一次跑完）
B 每次运行只做 1 个任务。要一次跑完整批：
- 在 ComfyUI 里开 **Auto Queue（自动队列）**：队列区的 `Extra options → Auto Queue`，勾上后每执行完会自动再排一次，直到队列空/你关闭。
- `Respect 分镜取任务` 设了 `IS_CHANGED`（每次强制重扫目录），所以每次自动排队都会取到**下一个**未做任务；`01_pending` 清空后 `has_job=false`，此时再跑不产出（手动停 Auto Queue 即可）。

> 注意：这个「循环」是 **ComfyUI 前端的 Auto Queue**，不是 Claude 的 `/loop`——`/loop` 跑在助手侧、驱动不了你本机的 ComfyUI。

## 章鱼哥 API（统一异步）—— `D_octopus_async.json`

章鱼哥所有生成都走同一套异步：`POST /v1/videos` 创建 → 拿 `task_id` → `GET /v1/videos/{id}` 轮询 → `completed` 后取 `url`/`video_url`。三个节点（分类 `Respect/章鱼哥`）：
- **Respect 章鱼哥 异步图片**：gpt-image-2 / -2K / -4K、nano_banana_2 / nano_banana_pro-1K/2K/4K → 提交+轮询+下载成 IMAGE
- **Respect 章鱼哥 异步视频**：sora-2-12s、omni_flash-10s、veo_3_1-fast/-fl/-hd/-4K/-lite、veo_3_1 → 提交+轮询+下载本地 mp4
- **Respect 章鱼哥 任务查询**：给 `task_id` 轮询取结果（「先提交、稍后查询」的真异步用；接创建节点的 `task_id` 输出）

demo（`D_octopus_async.json`）：
```
Respect API 设置(base_url=章鱼哥网关) ─┬─▶ 章鱼哥 异步图片(gpt-image-2) → 预览图像
                                      └─▶ 章鱼哥 异步视频(sora-2-12s) → 查看视频
```
- 创建/图生：参考图接 `image_1..4`（走 images[] base64，图片≤8、omni≤7）
- 图片 `size` 填了用像素、否则用 `aspect_ratio`；视频用 `size`（如 1280x720 横 / 720x1280 竖）
- 节点内部已做「提交→轮询到 completed」，所以直接接预览即可；要「提交后稍后再查」就用 `task_id` → 任务查询 节点
- 章鱼哥这套**没有 grok**（视频是 Sora/Omni/Veo）

## `E_extract_seconds_demo.json` —— 提取镜头秒数 独立 demo

单独演示「从文本抠镜头秒数 → 驱动视频时长」：
```
文字输入("8秒 | 人物走动…") ─┬─▶ Respect 提取镜头秒数(offset=1) → seconds ┐
加载图像 ────────────────────┼──▶ first_frame                              │
                             └──▶ grok.prompt                              ├─▶ Grok-Video(坤鸡, duration=seconds) → 查看视频
```
- 「提取镜头秒数」从文本抠出 8，+offset(1) 补删帧 → 9 → 作为 grok `duration`
- 也内置在 `B_video_produce.json`（分镜取任务.prompt → 提取镜头秒数 → grok.duration）
- 控制台会打印 `[Respect] 提取秒数: 抠到 8s + offset 1 → 夹到 9s` 便于核对

## `F_asset_library_demo.json` —— 关键词取素材（角色库）→ 输入到生成

演示「按名字从角色库调素材 → 喂给生图」：
```
文字输入("出场人物：小白，小黑") → Respect 关键词取素材（角色库, file_type=图片）
   ├ images ─▶ 预览图像（看取到的角色）
   └ images ─▶ image2.image_1（参考图）→ 生成 → 预览图像（看结果）
```
- 「关键词取素材」按 `keyword=出场人物` 抠出 `小白,小黑` → 去 `library_dir` 找 `小白.*/小黑.*`（`file_type` 决定后缀）
- 输出 `images`(图片批次) / `text`(文本文件内容) / `paths`(所有路径) / `names` / `count`
- image2 的参考图输入现在会**自动展开一个 IMAGE 批次里的每一张**，所以多角色都会当参考
- 换用途：`file_type=文本` → `text` 输出接 Chat 的 prompt（历史背景）；`file_type=视频` → `paths` 接视频节点

用前改：`library_dir` 填你的角色库目录，里面放 `小白.png`、`小黑.png`（或 `小白.txt` 历史背景等）。

## `G_split_json_items_demo.json` —— JSON 字段里的「1xxx，2xxx，3xxx」拆成每一项

**不需要 API Key 就能跑**（数据是节点里写死的示例文本），用来验证分段工具的两步取法。

```
Respect 文字输入（示例 JSON）
   └─▶ ① Respect 分段提取  method=json, json_path=关键物品
            └ seg_1 = "1染血白婚纱，2主卧手机，3露台护栏"
                 └─▶ ② Respect 分段提取  method=regex_findall, pattern=\d+\s*([^，,]+)
                          ├ seg_1 ─▶ Respect 显示文字   染血白婚纱
                          ├ seg_2 ─▶ Respect 显示文字   主卧手机
                          ├ seg_3 ─▶ Respect 显示文字   露台护栏
                          └ all_json ─▶ Respect 显示文字   ["染血白婚纱","主卧手机","露台护栏"]
```

**为什么要两步**：`"关键物品"` 的值是**一个字符串**，不是 JSON 数组。
① 先用 `json` 模式把字段值取出来；② 再用正则把里面的条目拆开。
`([^，,]+)` 是捕获组，节点取第一个非空捕获组，所以序号 `\d+` 被自动去掉（想保留序号就用 `delimiter`，`pattern` 填 `，`）。

> ⚠️ **不要**直接在完整 JSON 文本上跑 `\d+...` —— 会把别处的数字也匹配进来。必须先取字段。

换成你自己的数据：把「文字输入」换成 **Chat 对话** 的输出接到 ①.text 即可，其余不用改。
条目数不固定时，用 ②.`all_json` 接 **取第N段**，按 `index` 动态取。

## 各服务商「图片 → 视频」demo（H ~ M）

每个接入的服务商都有一个，结构完全一致，方便横向对比：

```
[Respect API 设置(base_url 已预填)] ──api_config──┬─▶ [该家 图片节点] ──image──┬─▶ [预览图像]
                                                 │                          └─▶ [该家 视频节点].参考图
                                                 └────────api_config───────────▶       │ local_path
                                                                                       ▼
                                                                             [Respect 查看视频]
```

| 文件 | 服务商 | base_url | 图片 → 视频 |
|---|---|---|---|
| `H_xiaopei_image_video_demo.json` | 小裴 / aicopy | `https://api.aicopy.top` | image2 → SD2.0 全系列视频（首帧生成） |
| `I_kunji_image_video_demo.json` | 坤鸡 | 图 `https://img.yunfei.best`／视频另填 | 坤鸡 图片 → Grok-Video（坤鸡分支） |
| `J_octopus_image_video_demo.json` | 章鱼哥 | 你的网关 | 章鱼哥 异步图片 → 异步视频 |
| `K_zero_image_video_demo.json` | 零视工坊 | `https://zeroapi.ai-ren.cn` | 零视工坊 图片 → 图生视频（seedance_2_fast_480p） |
| `L_lingganya_image_video_demo.json` | 灵感鸭 | `https://www.lingganyaapi.com` | 统一图片 → 统一视频（sd-fast, 9:16, 10秒） |
| `M_he_image_video_demo.json` | 鹤 / paisio | `https://api.paisio.online` | 鹤 图片生成 → 鹤 视频（sd2-pro-720p, 12秒） |

**用前只改两处**：① API 设置里的 `api_key`；② 提示词。`base_url` 已按各家预填。

⚠️ **坤鸡那个有两个 API 设置节点** —— 因为它图片（`img.yunfei.best`）和视频不是同一个域名，
视频那个的 `base_url` 需要你填自己的坤鸡视频网关。

各家参考图的传法不同（节点内部已处理好，知道就行）：
- 小裴：上传到 `upload_base_url` 换公网 URL（非 aicopy 的 Key 会 401 → 改用 `ref_url_*` 填公网 URL）
- 鹤 / paisio：**只吃 data URI 内联**，节点自动压成 1024px JPEG q80
- 章鱼哥 / 零视工坊 / 灵感鸭：`images[]` base64 或公网 URL（**优先填 URL**，个别网关会静默忽略 base64）
- 坤鸡：视频 multipart 直传；图片 `/v1/images/edits` 重复 `image` 字段

## 文字合并接法（在 UI 里手接，2 步）

分段/多路文字合成一段：

```
Respect 文字输入 ──text──▶ Respect 文字合并.text_1
Respect 文字输入 ──text──▶ Respect 文字合并.text_2   ──text──▶ 下游节点
```
或把 `Respect 分段提取` 的 `seg_1 / seg_2 / seg_3` 分别接到 `Respect 文字合并` 的 `text_1 / text_2 / text_3`，`separator` 填 `\n\n`。

段数不固定：用 `Respect 分段提取` 的 `all_json` 接多个 `Respect 取第N段`（各填不同 `index`，1 起），分别路由到不同下游。
或者填 `outputcount` 后点节点上的 **「更新输出口」** 按钮，直接把 `seg_1..seg_N` 开到需要的数量（1–200）。

## 导入前必读：版本要对上

这些示例 JSON 里存的控件值是**按当前代码的节点结构**排的。如果你运行的 ComfyUI 加载的是**旧版插件**，
导入后会出现**控件值整体错位一格**，典型症状：

- `pattern` 框里出现数字 `8`、`json_field` 里出现本该填 `json_path` 的内容
- 下拉框报 `Value not in list: match_mode: 'True' not in [...]`
- 分段跑完全是空的、`all_json` 显示 `[]`

**解决**：把插件目录同步到 **ComfyUI 实际加载的那个位置** → **完全重启 ComfyUI** → **Ctrl+F5** 强刷 → 重新导入 JSON。
（判断依据：新版分段节点有 `outputcount` 控件和「更新输出口」按钮；没有就是旧版。）

## 提示
- OpenAI 系（Chat/Responses）的 `json_schema` 严格模式要求 schema 带 `"additionalProperties": false` 且 `required` 覆盖所有字段（示例已满足）。
- Claude（Anthropic）无原生 `response_format`，节点会自动往 system 注入「只输出 JSON」的强制指令。
- 这些 JSON 是图格式；若你的 ComfyUI 版本较老载入异常，按上面的连线关系手接即可（节点都在 `Respect` 分类下）。
- 示例里的路径（PDF 目录、角色库、保存目录）都要改成你自己的；带 API 的示例还要在「Respect API 设置」里填对
  `base_url`（见主 README 的[网关对照表](../README.md#网关对照表)）。
- 参考图尽量走**公网 URL**（接「对象存储上传」）——部分网关会静默忽略 base64，表现为「出了视频但没参考图」。
